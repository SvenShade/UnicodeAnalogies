# INFORMATION ------------------------------------------------------------------------------------------------------- #


# Author:  Honghua Dong.
# Email:   dhh19951@gmail.com
# Date:    11/21/2019
# Purpose: Defines the SCL model.

# Ported by Steven Spratley, to be tested with the Unicode Analogies dataset.


# IMPORTS ----------------------------------------------------------------------------------------------------------- #


import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from jactorch.quickstart.models import MLPModel
from .baselines import SimpleModel, SharedModel
from .symbolic_model import AnalogyModel
from .utils import compute_entropy, compute_mi
from .visual_model import Visual2Symbolic
from ..constant import MAX_VALUE


# MODEL CLASS ------------------------------------------------------------------------------------------------------- #


class SCL(nn.Module):
    def __init__(self, model='scl'):
        super(SCL, self).__init__()
        self.model     = model
        self.SCL       = nn.DataParallel(SCL_model(), device_ids=[0,1])
        self.optimizer = torch.optim.Adam([param for param in self.parameters() if param.requires_grad],
                                           lr=1e-3, weight_decay=1e-2)
        
    def compute_loss(self, output, target):
        return F.cross_entropy(output, target)
    
    def train_(self, image, target):
        self.optimizer.zero_grad()
        output = self(image)
        loss = self.compute_loss(output, target)
        loss.backward()
        self.optimizer.step()
        pred = output.data.max(1)[1]
        correct = pred.eq(target.data).cpu().sum().numpy()
        accuracy = correct * 100.0 / target.size()[0]
        return loss.item(), accuracy

    def test_(self, image, target):
        with torch.no_grad():
            output = self(image)
        pred = output.data.max(1)[1]
        correct = pred.eq(target.data).cpu().sum().numpy()
        accuracy = correct * 100.0 / target.size()[0]
        return accuracy 
    
    def forward(self, x):
        return self.SCL(x)
    
    
class SCL_model(nn.Module):
    def __init__(self,
            nr_features=80,
            model_name='analogy',
            nr_experts=5,
            shared_group_mlp=True,
            max_value=MAX_VALUE,
            not_use_softmax=True,
            visual_inputs=True,
            factor_groups=10,
            split_channel=False,
            image_size=(80,80),
            use_layer_norm=False,
            use_resnet=False,
            conv_hidden_dims=[16, 16, 32, 32],
            conv_repeats=None,
            conv_kernels=3,
            conv_residual_link=True,
            nr_visual_experts=1,
            visual_mlp_hidden_dims=[128],
            transformed_spatial_dim=80,
            mlp_transform_hidden_dims=[],
            exclude_angle_attr=False,
            prediction_beta=1.0,
            embedding_dim=None,
            embedding_hidden_dims=[],
            enable_residual_block=True,
            use_ordinary_mlp=False,
            enable_rb_after_experts=True,
            feature_embedding_dim=1,
            hidden_dims=[64, 32],
            reduction_groups=[2],
            sum_as_reduction=0,
            lastmlp_hidden_dims=[128],
            nr_context=8,
            nr_candidates=8,
            collect_inter_key=None):
        super(SCL_model, self).__init__()

        self.original_nr_feature = nr_features
        self.visual_inputs = visual_inputs
        self.v2s = Visual2Symbolic(
            input_dim=1,
            shared_group_mlp=shared_group_mlp,
            conv_hidden_dims=conv_hidden_dims,
            output_dim=nr_features,
            use_resnet=use_resnet,
            conv_repeats=conv_repeats,
            conv_kernels=conv_kernels,
            conv_residual_link=conv_residual_link,
            nr_visual_experts=nr_visual_experts,
            mlp_hidden_dims=visual_mlp_hidden_dims,
            groups=factor_groups,
            split_channel=split_channel,
            transformed_spatial_dim=transformed_spatial_dim,
            mlp_transform_hidden_dims=mlp_transform_hidden_dims,
            image_size=image_size,
            use_layer_norm=use_layer_norm)
        self.nr_features = nr_features
        self.max_value = max_value
        self.symbolic_model = AnalogyModel(
                nr_features=nr_features,
                nr_experts=nr_experts,
                shared_group_mlp=shared_group_mlp,
                not_use_softmax=not_use_softmax,
                embedding_dim=embedding_dim,
                embedding_hidden_dims=embedding_hidden_dims,
                enable_residual_block=enable_residual_block,
                enable_rb_after_experts=enable_rb_after_experts,
                feature_embedding_dim=feature_embedding_dim,
                hidden_dims=hidden_dims,
                reduction_groups=reduction_groups,
                sum_as_reduction=sum_as_reduction,
                lastmlp_hidden_dims=lastmlp_hidden_dims,
                use_ordinary_mlp=use_ordinary_mlp,
                nr_context=nr_context,
                nr_candidates=nr_candidates,
                collect_inter_key=collect_inter_key)

    def forward(self, x):
        return self.symbolic_model(self.v2s(x))


# END FILE ---------------------------------------------------------------------------------------------------------- #