#! /usr/bin/env python3
# -*- coding: utf-8 -*-
# File   : g.py
# Author : Jiayuan Mao
# Email  : maojiayuan@gmail.com
# Date   : 05/12/2018
#
# This file is part of Jacinle.
# Distributed under terms of the MIT license.

from jacinle.utils.container import g

__all__ = ['g']

