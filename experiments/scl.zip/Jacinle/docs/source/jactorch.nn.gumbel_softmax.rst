jactorch.nn.gumbel\_softmax package
===================================

.. automodule:: jactorch.nn.gumbel_softmax
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

jactorch.nn.gumbel\_softmax.functional module
---------------------------------------------

.. automodule:: jactorch.nn.gumbel_softmax.functional
   :members:
   :undoc-members:
   :show-inheritance:

jactorch.nn.gumbel\_softmax.softmax module
------------------------------------------

.. automodule:: jactorch.nn.gumbel_softmax.softmax
   :members:
   :undoc-members:
   :show-inheritance:
