jaclearn.math package
=====================

.. automodule:: jaclearn.math
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

jaclearn.math.rotation module
-----------------------------

.. automodule:: jaclearn.math.rotation
   :members:
   :undoc-members:
   :show-inheritance:
