jactorch.nn.neural\_logic package
=================================

.. automodule:: jactorch.nn.neural_logic
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 2

   jactorch.nn.neural_logic.modules

Submodules
----------

jactorch.nn.neural\_logic.layer module
--------------------------------------

.. automodule:: jactorch.nn.neural_logic.layer
   :members:
   :undoc-members:
   :show-inheritance:

jactorch.nn.neural\_logic.recurrent\_layer module
-------------------------------------------------

.. automodule:: jactorch.nn.neural_logic.recurrent_layer
   :members:
   :undoc-members:
   :show-inheritance:
