jaclearn.embedding package
==========================

.. automodule:: jaclearn.embedding
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

jaclearn.embedding.constant module
----------------------------------

.. automodule:: jaclearn.embedding.constant
   :members:
   :undoc-members:
   :show-inheritance:

jaclearn.embedding.embedding\_utils module
------------------------------------------

.. automodule:: jaclearn.embedding.embedding_utils
   :members:
   :undoc-members:
   :show-inheritance:

jaclearn.embedding.visualize\_tb module
---------------------------------------

.. automodule:: jaclearn.embedding.visualize_tb
   :members:
   :undoc-members:
   :show-inheritance:

jaclearn.embedding.word\_embedding module
-----------------------------------------

.. automodule:: jaclearn.embedding.word_embedding
   :members:
   :undoc-members:
   :show-inheritance:
