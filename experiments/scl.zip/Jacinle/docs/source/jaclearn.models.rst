jaclearn.models package
=======================

.. automodule:: jaclearn.models
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 2

   jaclearn.models.naive_bayes
