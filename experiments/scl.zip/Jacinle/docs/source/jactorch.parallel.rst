jactorch.parallel package
=========================

.. automodule:: jactorch.parallel
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

jactorch.parallel.comm module
-----------------------------

.. automodule:: jactorch.parallel.comm
   :members:
   :undoc-members:
   :show-inheritance:

jactorch.parallel.data\_parallel module
---------------------------------------

.. automodule:: jactorch.parallel.data_parallel
   :members:
   :undoc-members:
   :show-inheritance:

jactorch.parallel.dict\_gather module
-------------------------------------

.. automodule:: jactorch.parallel.dict_gather
   :members:
   :undoc-members:
   :show-inheritance:

jactorch.parallel.replicate module
----------------------------------

.. automodule:: jactorch.parallel.replicate
   :members:
   :undoc-members:
   :show-inheritance:

jactorch.parallel.replication\_callback module
----------------------------------------------

.. automodule:: jactorch.parallel.replication_callback
   :members:
   :undoc-members:
   :show-inheritance:

jactorch.parallel.user\_scattered module
----------------------------------------

.. automodule:: jactorch.parallel.user_scattered
   :members:
   :undoc-members:
   :show-inheritance:
