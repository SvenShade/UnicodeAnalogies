jactorch.transforms.bbox package
================================

.. automodule:: jactorch.transforms.bbox
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

jactorch.transforms.bbox.functional module
------------------------------------------

.. automodule:: jactorch.transforms.bbox.functional
   :members:
   :undoc-members:
   :show-inheritance:

jactorch.transforms.bbox.transforms module
------------------------------------------

.. automodule:: jactorch.transforms.bbox.transforms
   :members:
   :undoc-members:
   :show-inheritance:
