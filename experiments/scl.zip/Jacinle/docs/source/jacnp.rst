jacnp package
=============

.. automodule:: jacnp
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

jacnp.batch module
------------------

.. automodule:: jacnp.batch
   :members:
   :undoc-members:
   :show-inheritance:

jacnp.indexing module
---------------------

.. automodule:: jacnp.indexing
   :members:
   :undoc-members:
   :show-inheritance:

jacnp.nd module
---------------

.. automodule:: jacnp.nd
   :members:
   :undoc-members:
   :show-inheritance:

jacnp.shape module
------------------

.. automodule:: jacnp.shape
   :members:
   :undoc-members:
   :show-inheritance:
