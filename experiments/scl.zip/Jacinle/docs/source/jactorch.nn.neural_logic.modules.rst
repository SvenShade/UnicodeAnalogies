jactorch.nn.neural\_logic.modules package
=========================================

.. automodule:: jactorch.nn.neural_logic.modules
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

jactorch.nn.neural\_logic.modules.dimension module
--------------------------------------------------

.. automodule:: jactorch.nn.neural_logic.modules.dimension
   :members:
   :undoc-members:
   :show-inheritance:

jactorch.nn.neural\_logic.modules.neural\_logic module
------------------------------------------------------

.. automodule:: jactorch.nn.neural_logic.modules.neural_logic
   :members:
   :undoc-members:
   :show-inheritance:
