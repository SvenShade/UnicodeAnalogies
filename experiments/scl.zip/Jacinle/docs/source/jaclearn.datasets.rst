jaclearn.datasets package
=========================

.. automodule:: jaclearn.datasets
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 2

   jaclearn.datasets.image_classification
