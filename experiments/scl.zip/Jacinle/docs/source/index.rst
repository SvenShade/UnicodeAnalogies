.. Jacinle documentation master file, created by
   sphinx-quickstart on Sat Apr 21 16:51:41 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

============
Jacinle
============

Jacinle is a personal python toolbox developed by Jiayuan Mao (github: @vacancy). It contains a range of utility functions for python development, including project configuration, file IO, image processing, inter-process communication, etc.

Note
===============
Comming soon.

Package Reference
=================

.. toctree::
   :maxdepth: 1

   jacinle
   jaclearn
   jacnp
   jactf
   jactorch
   jacweb


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

