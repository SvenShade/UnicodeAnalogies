#! /usr/bin/env python3
# -*- coding: utf-8 -*-
# File   : graph_cut.py
# Author : Jiayuan Mao
# Email  : maojiayuan@gmail.com
# Date   : 01/07/2020
#
# This file is part of Jacinle.
# Distributed under terms of the MIT license.

from pygco import cut_general_graph, cut_grid_graph, cut_grid_graph_simple

